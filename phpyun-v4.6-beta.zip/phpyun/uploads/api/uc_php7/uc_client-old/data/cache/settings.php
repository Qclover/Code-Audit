<?php
/*
* $Author ：PHPYUN开发团队
*
* 官网: http://www.phpyun.com
*
* 版权所有 2009-2018 宿迁鑫潮信息技术有限公司，并保留所有权利。
*
* 软件声明：未经授权前提下，不得用于商业运营、二次开发以及任何形式的再次发布。
 */
$_CACHE['settings'] = array (
  'accessemail' => '',
  'censoremail' => '',
  'censorusername' => '',
  'dateformat' => 'y-n-j',
  'doublee' => '0',
  'nextnotetime' => '0',
  'timeoffset' => '28800',
  'privatepmthreadlimit' => '25',
  'chatpmthreadlimit' => '30',
  'chatpmmemberlimit' => '35',
  'pmfloodctrl' => '15',
  'pmcenter' => '1',
  'sendpmseccode' => '1',
  'pmsendregdays' => '0',
  'maildefault' => 'username@21cn.com',
  'mailsend' => '1',
  'mailserver' => 'smtp.21cn.com',
  'mailport' => '25',
  'mailauth' => '1',
  'mailfrom' => 'UCenter <username@21cn.com>',
  'mailauth_username' => 'username@21cn.com',
  'mailauth_password' => 'password',
  'maildelimiter' => '0',
  'mailusername' => '1',
  'mailsilent' => '1',
  'version' => '1.6.0',
);

?>
<?php
class friend_typecontrol {
  
}
?>
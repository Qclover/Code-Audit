<?php
class friendmodel {
    
}
?>
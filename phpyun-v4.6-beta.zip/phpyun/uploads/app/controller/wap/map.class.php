<?php
/*
* $Author ：PHPYUN开发团队
*
* 官网: http://www.phpyun.com
*
* 版权所有 2009-2018 宿迁鑫潮信息技术有限公司，并保留所有权利。
*
* 软件声明：未经授权前提下，不得用于商业运营、二次开发以及任何形式的再次发布。
 */
class map_controller extends common{
	function index_action(){
		$this->get_moblie();
        $this->yunset("title","附近职位"); 
		$this->yuntpl(array('wap/map'));
	}
	
	function maplist_action(){
		$this->get_moblie();
        $this->yunset("title","附近职位"); 
		$this->yuntpl(array('wap/maplist'));
	}
	
	function joblist_action(){
	    $this->get_moblie();
	    $CompanyM=$this->MODEL('company');
	    $JobM=$this->MODEL('job');
	    $xy=getAround($_POST['x'],$_POST['y'],'5000');
	    $comrows=$CompanyM->GetComList(array('name<>'=>'','hy<>'=>'','r_status<>'=>'2','x>'=>$xy[0],'x<'=>$xy['1'],'y>'=>$xy['3'],'y<'=>$xy[2]),array('field'=>'uid,welfare,address,x,y'));
	    if($comrows){
	        foreach($comrows as $k=>$v){
	            $uids[]=$v['uid'];
	            $distance=$this->GetDistance($_POST['x'],$_POST['y'],$v['x'],$v['y']);
	            $comrows[$k]['distance']=$distance;
	        }
	        $joball=$JobM->GetComjobList(array('r_status'=>'1','status'=>'0','state'=>'1',"`uid` in(".pylode(',',$uids).")"),array('field'=>'id,uid,name,com_name,minsalary,maxsalary','orderby'=>'uid','desc'=>'desc'));
	        $data['pagecount']=ceil(count($joball)/10);
	        if($_POST['page']){
	            $pagenav=($_POST['page']-1)*10;
	            $limit="$pagenav,10";
	            $joball=$JobM->GetComjobList(array('r_status'=>'1','status'=>'0','state'=>'1',"`uid` in(".pylode(',',$uids).")"),array('field'=>'id,uid,name,com_name,minsalary,maxsalary','limit'=>$limit,'orderby'=>'uid','desc'=>'desc'));
	        }
	        if($joball){
	            $list=array();
	            foreach ($joball as $key=>$val){
	                foreach ($comrows as $v){
	                    if ($val['uid']==$v['uid']) {
	                        if($v['shortname']){
	                            $list[$key]['com_name']=mb_substr($v['shortname'], 0,16,'utf-8');
	                        }else{
	                            $list[$key]['com_name']=mb_substr($val['com_name'], 0,16,'utf-8');
	                        }
	                        if($v['welfare']){
	                            $list[$key]['welfare']=@explode(",",$v['welfare']);
	                        }
	                        $list[$key]['address']=$v['address'];
	                        $list[$key]['distance']=$v['distance'];
	                        $list[$key]['x']=$v['x'];
	                        $list[$key]['y']=$v['y'];
	                    }
	                    $list[$key]['id']      =$val['id'];
	                    $list[$key]['name']    =mb_substr($val['name'], 0,16,'utf-8');
	                    if ($val['minsalary']){
	                        if ($val['maxsalary']>0){
	                            $list[$key]['salary_n']='￥'.$val['minsalary'].'-'.$val['maxsalary'];
	                        }else{
	                            $list[$key]['salary_n']='￥'.$val['minsalary'].'以上';
	                        }
	                    }else{
	                        $list[$key]['salary_n']='面议';
	                    }
	                    $list[$key]['joburl']  =Url('wap',array('c'=>'job','a'=>'view','id'=>$val['id']));
	                    $list[$key]['comurl']  =Url('wap',array('c'=>'company','a'=>'show','id'=>$val['uid']));
	                    $list[$key]['addressurl']  =Url('wap',array('c'=>'map','a'=>'jobmap','id'=>$val['uid']));
	                }
	            }
	            $joblist=$this->arraySequence($list, 'distance');
	            foreach ($joblist as $key=>$value){
	                if(is_float($value['distance'])){
	                    if($value['distance']<=1){
	                        $joblist[$key]['dis']=ceil($value['distance']*1000).'m';
	                    }else{
	                        $joblist[$key]['dis']=round($value['distance'], 2).'km';
	                    }
	                }else{
	                    $joblist[$key]['dis']='距离不详';
	                }
	            }
	        }
	    }
	    $jobnum = count($joblist);
	    $data['list']=$jobnum>0?$joblist:array();
	    $data['jobnum']=$jobnum;
	    $data['error']=0;
	    echo json_encode($data);die;
	}
	function comlist_action(){
	    $xy=getAround($_POST['x'],$_POST['y'],'5000');
	    $CompanyM=$this->MODEL('company');
	    $comrows=$CompanyM->GetComList(array('name<>'=>'','hy<>'=>'','r_status<>'=>'2','x>'=>$xy[0],'x<'=>$xy['1'],'y>'=>$xy['3'],'y<'=>$xy[2]),array('field'=>'uid,name,shortname,welfare,address,x,y'));
	    if($comrows){
	        foreach($comrows as $k=>$v){
	            $uids[]=$v['uid'];
	            $distance=$this->GetDistance($_POST['x'],$_POST['y'],$v['x'],$v['y']);
	            $comrows[$k]['distance']=$distance;
	        }
	        $JobM=$this->MODEL('job');
	        $joball=$JobM->GetComjobList(array('r_status'=>'1','status'=>'0','state'=>'1',"`uid` in(".pylode(',',$uids).")"),array('field'=>'id,uid,name'));
	        if($joball){
	            $list=array();
	            foreach ($comrows as $k=>$v){
	                foreach ($joball as $val){
	                    if ($val['uid']==$v['uid']) {
	                        if($v['shortname']){
	                            $list[$k]['com_name']=mb_substr($v['shortname'], 0,16,'utf-8');
	                        }else{
	                            $list[$k]['com_name']=mb_substr($v['name'], 0,16,'utf-8');
	                        }
	                        $list[$k]['distance']=$v['distance'];
	                        $list[$k]['x']=$v['x'];
	                        $list[$k]['y']=$v['y'];
	                        $list[$k]['comurl']=Url('wap',array('c'=>'company','a'=>'show','id'=>$v['uid']));
	                        $val['joburl']=Url('wap',array('c'=>'job','a'=>'view','id'=>$val['id']));
	                        $list[$k]['joblist'][]=$val;
	                    }
	                }
	            }
	            $joblist=$this->arraySequence($list, 'distance');
	            foreach ($joblist as $key=>$value){
	                if(is_float($value['distance'])){
	                    if($value['distance']<=1){
	                        $joblist[$key]['dis']=ceil($value['distance']*1000).'m';
	                    }else{
	                        $joblist[$key]['dis']=round($value['distance'], 2).'km';
	                    }
	                }else{
	                    $joblist[$key]['dis']='距离不详';
	                }
	            }
	            $page = $_POST['page'];
	            foreach ($joblist as $k=>$v){
	                if($page==1){
	                    if ($k<10){
	                        $arr[]=$v;
	                    }
	                }elseif($page>1){
	                    $lpage=$page*10;
	                    $rpage=(($page+1)*10);
	                    if($k>=$lpage && $k<$rpage){
	                        $arr[]=$v;
	                    }
	                }
	            }
	        }
	    }
	    $data['list']=count($arr)>0?$arr:array();
	    $data['pagecount']=ceil(count($comrows)/10);
	    $data['error']=0;
	    echo json_encode($data);die;
	}
	
	function jobmap_action(){
	    $this->get_moblie();
	    $this->yunset("title","附近职位"); 
	    $comid = intval($_GET['id']);
	    $companyM = $this->MODEL('company');
	    $com = $companyM->GetCompanyInfo(array('uid'=>$comid),array('field'=>'`uid`,`name`,`cityid`,`address`,`x`,`y`'));
	    $CacheM=$this->MODEL('cache');
	    $CacheArr=$CacheM->GetCache(array('city'));
	    $cityname = $CacheArr['city_name'][$com['cityid']];
	    $this->yunset('cityname',$cityname);
	    $this->yunset('com',$com);
	    $user_agent = ( !isset($_SERVER['HTTP_USER_AGENT'])) ? FALSE : $_SERVER['HTTP_USER_AGENT'];
	    if ($_COOKIE['mapx']>0 && $_COOKIE['mapy']>0 && strpos($user_agent, 'Android')){
	        $this->yunset(array('mapx'=>$_COOKIE['mapx'],'mapy'=>$_COOKIE['mapy']));
	    }else{
	        $this->yunset(array('mapx'=>0,'mapy'=>0));
	    }
	    $this->yuntpl(array('wap/com_map'));
	}
	function GetDistance($lat1, $lng1, $lat2, $lng2){
        define('PI',3.1415926535898);
        define('EARTH_RADIUS',6378.137);
        $radLat1 = $lat1 * (PI / 180);
        $radLat2 = $lat2 * (PI / 180);

        $a = $radLat1 - $radLat2;
        $b = ($lng1 * (PI / 180)) - ($lng2 * (PI / 180));

        $s = 2 * asin(sqrt(pow(sin($a/2),2) + cos($radLat1)*cos($radLat2)*pow(sin($b/2),2)));
        $s = $s * EARTH_RADIUS;
        $s = round($s * 10000) / 10000;
        return $s;
    }
    function arraySequence($array, $field, $sort = 'SORT_ASC'){
        $arrSort = array();
        foreach ($array as $uniqid => $row) {
            foreach ($row as $key => $value) {
                $arrSort[$key][$uniqid] = $value;
            }
        }
        array_multisort($arrSort[$field], constant($sort), $array);
        return $array;
    }
}
?>
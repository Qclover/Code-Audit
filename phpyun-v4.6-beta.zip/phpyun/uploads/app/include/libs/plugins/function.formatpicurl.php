<?php
function smarty_function_formatpicurl($paramer,$template){ 
	return FormatPicUrl($paramer);
}
?>